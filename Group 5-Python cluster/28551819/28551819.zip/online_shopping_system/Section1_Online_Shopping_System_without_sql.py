from datetime import date

class Product:
    def __init__(self, product_id, name, category, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity

    def __str__(self):
        return f"Product [ID: {self.product_id}, Name: {self.name}, Category: {self.category}, Price: {self.price}, Stock: {self.stock_quantity}]"

class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

    def __str__(self):
        return f"Customer [ID: {self.customer_id}, Name: {self.name}, Email: {self.email}, Address: {self.address}]"

class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order [ID: {self.order_id}, Customer ID: {self.customer_id}, Product ID: {self.product_id}, Date: {self.order_date}, Quantity: {self.quantity}]"

class OnlineShoppingSystem:
    def __init__(self):
        self.products = {}
        self.customers = {}
        self.orders = {}

    # Product Management
    def add_product(self, product):
        if product.product_id in self.products:
            raise Exception("Product ID already exists.")
        self.products[product.product_id] = product

    def update_product(self, product_id, **kwargs):
        if product_id not in self.products:
            raise Exception("Product not found.")
        for key, value in kwargs.items():
            setattr(self.products[product_id], key, value)

    def delete_product(self, product_id):
        if product_id not in self.products:
            raise Exception("Product not found.")
        del self.products[product_id]

    # Customer Management
    def add_customer(self, customer):
        if customer.customer_id in self.customers:
            raise Exception("Customer ID already exists.")
        self.customers[customer.customer_id] = customer

    def update_customer(self, customer_id, **kwargs):
        if customer_id not in self.customers:
            raise Exception("Customer not found.")
        for key, value in kwargs.items():
            setattr(self.customers[customer_id], key, value)

    def delete_customer(self, customer_id):
        if customer_id not in self.customers:
            raise Exception("Customer not found.")
        del self.customers[customer_id]

    # Order Management
    def add_order(self, order):
        if order.order_id in self.orders:
            raise Exception("Order ID already exists.")
        if order.customer_id not in self.customers:
            raise Exception("Customer not found.")
        if order.product_id not in self.products:
            raise Exception("Product not found.")
        if self.products[order.product_id].stock_quantity < order.quantity:
            raise Exception("Not enough stock.")
        self.products[order.product_id].stock_quantity -= order.quantity
        self.orders[order.order_id] = order

    def update_order(self, order_id, **kwargs):
        if order_id not in self.orders:
            raise Exception("Order not found.")
        order = self.orders[order_id]
        if "quantity" in kwargs:
            new_quantity = kwargs["quantity"]
            diff = new_quantity - order.quantity
            if self.products[order.product_id].stock_quantity < diff:
                raise Exception("Not enough stock.")
            self.products[order.product_id].stock_quantity -= diff
        for key, value in kwargs.items():
            setattr(order, key, value)

    def delete_order(self, order_id):
        if order_id not in self.orders:
            raise Exception("Order not found.")
        order = self.orders[order_id]
        self.products[order.product_id].stock_quantity += order.quantity
        del self.orders[order_id]

def product_management(system):
    while True:
        print("\nProduct Management")
        print("1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Show Products")
        print("0. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            product_id = int(input("Enter product ID: "))
            name = input("Enter product name: ")
            category = input("Enter product category: ")
            price = float(input("Enter product price: "))
            stock_quantity = int(input("Enter product stock quantity: "))
            product = Product(product_id, name, category, price, stock_quantity)
            try:
                system.add_product(product)
                print("Product added successfully.")
            except Exception as e:
                print(e)

        elif choice == '2':
            product_id = int(input("Enter product ID to update: "))
            name = input("Enter new product name (or leave blank): ")
            category = input("Enter new product category (or leave blank): ")
            price = input("Enter new product price (or leave blank): ")
            stock_quantity = input("Enter new product stock quantity (or leave blank): ")
            updates = {}
            if name:
                updates['name'] = name
            if category:
                updates['category'] = category
            if price:
                updates['price'] = float(price)
            if stock_quantity:
                updates['stock_quantity'] = int(stock_quantity)
            try:
                system.update_product(product_id, **updates)
                print("Product updated successfully.")
            except Exception as e:
                print(e)

        elif choice == '3':
            product_id = int(input("Enter product ID to delete: "))
            try:
                system.delete_product(product_id)
                print("Product deleted successfully.")
            except Exception as e:
                print(e)

        elif choice == '4':
            print("Products:")
            for product in system.products.values():
                print(product)

        elif choice == '0':
            break

        else:
            print("Invalid choice. Please try again.")

def customer_management(system):
    while True:
        print("\nCustomer Management")
        print("1. Add Customer")
        print("2. Update Customer")
        print("3. Delete Customer")
        print("4. Show Customers")
        print("0. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            customer_id = int(input("Enter customer ID: "))
            name = input("Enter customer name: ")
            email = input("Enter customer email: ")
            address = input("Enter customer address: ")
            customer = Customer(customer_id, name, email, address)
            try:
                system.add_customer(customer)
                print("Customer added successfully.")
            except Exception as e:
                print(e)

        elif choice == '2':
            customer_id = int(input("Enter customer ID to update: "))
            name = input("Enter new customer name (or leave blank): ")
            email = input("Enter new customer email (or leave blank): ")
            address = input("Enter new customer address (or leave blank): ")
            updates = {}
            if name:
                updates['name'] = name
            if email:
                updates['email'] = email
            if address:
                updates['address'] = address
            try:
                system.update_customer(customer_id, **updates)
                print("Customer updated successfully.")
            except Exception as e:
                print(e)

        elif choice == '3':
            customer_id = int(input("Enter customer ID to delete: "))
            try:
                system.delete_customer(customer_id)
                print("Customer deleted successfully.")
            except Exception as e:
                print(e)

        elif choice == '4':
            print("Customers:")
            for customer in system.customers.values():
                print(customer)

        elif choice == '0':
            break

        else:
            print("Invalid choice. Please try again.")

def order_management(system):
    while True:
        print("\nOrder Management")
        print("1. Add Order")
        print("2. Update Order")
        print("3. Delete Order")
        print("4. Show Orders")
        print("0. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            order_id = int(input("Enter order ID: "))
            customer_id = int(input("Enter customer ID: "))
            product_id = int(input("Enter product ID: "))
            order_date = date.today()
            quantity = int(input("Enter quantity: "))
            order = Order(order_id, customer_id, product_id, order_date, quantity)
            try:
                system.add_order(order)
                print("Order added successfully.")
            except Exception as e:
                print(e)

        elif choice == '2':
            order_id = int(input("Enter order ID to update: "))
            customer_id = input("Enter new customer ID (or leave blank): ")
            product_id = input("Enter new product ID (or leave blank): ")
            quantity = input("Enter new quantity (or leave blank): ")
            updates = {}
            if customer_id:
                updates['customer_id'] = int(customer_id)
            if product_id:
                updates['product_id'] = int(product_id)
            if quantity:
                updates['quantity'] = int(quantity)
            try:
                system.update_order(order_id, **updates)
                print("Order updated successfully.")
            except Exception as e:
                print(e)

        elif choice == '3':
            order_id = int(input("Enter order ID to delete: "))
            try:
                system.delete_order(order_id)
                print("Order deleted successfully.")
            except Exception as e:
                print(e)

        elif choice == '4':
            print("Orders:")
            for order in system.orders.values():
                print(order)

        elif choice == '0':
            break

        else:
            print("Invalid choice. Please try again.")

def main():
    system = OnlineShoppingSystem()

    while True:
        print("\nWelcome to Online Shopping System")
        print("1. Product Management")
        print("2. Customer Management")
        print("3. Order Management")
        print("0. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            product_management(system)

        elif choice == '2':
            customer_management(system)

        elif choice == '3':
            order_management(system)

        elif choice == '0':
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
