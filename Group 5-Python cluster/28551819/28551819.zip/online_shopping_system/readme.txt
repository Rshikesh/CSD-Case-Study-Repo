Online Shopping System 

1.Section 1: Created a python file named "Online Shopping System without sql".

2.Section 2: Created a Text Filefor SQL with Schema and Queries for given problem statement.

3.Since I am not clear with whether the solution should be integrated with sql or not , i have created another python program with sql connection.