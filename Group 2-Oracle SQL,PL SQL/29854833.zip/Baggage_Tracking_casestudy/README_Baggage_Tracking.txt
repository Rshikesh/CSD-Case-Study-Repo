
# Baggage Tracking System for Airlines

## Introduction

This project implements a Baggage Tracking System for Airlines using Oracle SQL and PL/SQL. The system tracks baggage by tag numbers, updates their statuses, and generates tracking reports. The following functionalities are provided:
- Tracking new baggage
- Updating the status of baggage
- Generating tracking reports

## Database Schema

The system uses three tables:

### BaggageTracking
- **BAGGAGE_TAG_NUMBER**: VARCHAR2(50), Primary Key
- **FLIGHT_NUMBER**: VARCHAR2(50)
- **DESTINATION**: VARCHAR2(50)
- **CURRENT_LOCATION**: VARCHAR2(50)
- **STATUS**: VARCHAR2(50)
- **LAST_UPDATED**: DATE

### StatusUpdates
- **UPDATE_ID**: NUMBER, Primary Key
- **BAGGAGE_TAG_NUMBER**: VARCHAR2(50), Foreign Key References BaggageTracking(BAGGAGE_TAG_NUMBER)
- **UPDATED_BY**: VARCHAR2(50)
- **UPDATE_DATE**: DATE
- **NEW_STATUS**: VARCHAR2(50)

### TrackingReports
- **REPORT_ID**: NUMBER, Primary Key
- **REPORT_DATE**: DATE
- **TOTAL_BAGGAGE**: NUMBER
- **BAGGAGE_AT_LOCATION**: CLOB
- **STATUS_SUMMARY**: CLOB

## Setup Instructions

### 1. Create Database Schema

Run the following SQL scripts to create the tables:

```sql
CREATE TABLE BaggageTracking (
    BAGGAGE_TAG_NUMBER VARCHAR2(50) PRIMARY KEY,
    FLIGHT_NUMBER VARCHAR2(50),
    DESTINATION VARCHAR2(50),
    CURRENT_LOCATION VARCHAR2(50),
    STATUS VARCHAR2(50),
    LAST_UPDATED DATE
);

CREATE TABLE StatusUpdates (
    UPDATE_ID NUMBER PRIMARY KEY,
    BAGGAGE_TAG_NUMBER VARCHAR2(50),
    UPDATED_BY VARCHAR2(50),
    UPDATE_DATE DATE,
    NEW_STATUS VARCHAR2(50),
    FOREIGN KEY (BAGGAGE_TAG_NUMBER) REFERENCES BaggageTracking(BAGGAGE_TAG_NUMBER)
);

CREATE TABLE TrackingReports (
    REPORT_ID NUMBER PRIMARY KEY,
    REPORT_DATE DATE,
    TOTAL_BAGGAGE NUMBER,
    BAGGAGE_AT_LOCATION CLOB,
    STATUS_SUMMARY CLOB
);
```

### 2. Insert Sample Data

Run the following SQL scripts to insert sample data into the `BaggageTracking` and `StatusUpdates` tables:

```sql
INSERT INTO BaggageTracking (BAGGAGE_TAG_NUMBER, FLIGHT_NUMBER, DESTINATION, CURRENT_LOCATION, STATUS, LAST_UPDATED)
VALUES ('TAG123', 'FL123', 'JFK', 'LAX', 'In Transit', SYSDATE);

INSERT INTO BaggageTracking (BAGGAGE_TAG_NUMBER, FLIGHT_NUMBER, DESTINATION, CURRENT_LOCATION, STATUS, LAST_UPDATED)
VALUES ('TAG124', 'FL124', 'LHR', 'JFK', 'Checked In', SYSDATE);

INSERT INTO StatusUpdates (UPDATE_ID, BAGGAGE_TAG_NUMBER, UPDATED_BY, UPDATE_DATE, NEW_STATUS)
VALUES (1, 'TAG123', 'Agent1', SYSDATE, 'In Transit');

INSERT INTO StatusUpdates (UPDATE_ID, BAGGAGE_TAG_NUMBER, UPDATED_BY, UPDATE_DATE, NEW_STATUS)
VALUES (2, 'TAG124', 'Agent2', SYSDATE, 'Checked In');
```

### 3. PL/SQL Procedures

Create the following PL/SQL procedures to handle baggage tracking, status updates, and report generation:

#### TrackBaggage Procedure

```plsql
CREATE OR REPLACE PROCEDURE TrackBaggage(
    p_baggage_tag_number IN VARCHAR2,
    p_flight_number IN VARCHAR2,
    p_destination IN VARCHAR2,
    p_current_location IN VARCHAR2,
    p_status IN VARCHAR2
) AS
BEGIN
    INSERT INTO BaggageTracking (BAGGAGE_TAG_NUMBER, FLIGHT_NUMBER, DESTINATION, CURRENT_LOCATION, STATUS, LAST_UPDATED)
    VALUES (p_baggage_tag_number, p_flight_number, p_destination, p_current_location, p_status, SYSDATE);
END;
/
```

#### UpdateBaggageStatus Procedure

```plsql
CREATE OR REPLACE PROCEDURE UpdateBaggageStatus(
    p_update_id IN NUMBER,
    p_baggage_tag_number IN VARCHAR2,
    p_updated_by IN VARCHAR2,
    p_new_status IN VARCHAR2
) AS
BEGIN
    INSERT INTO StatusUpdates (UPDATE_ID, BAGGAGE_TAG_NUMBER, UPDATED_BY, UPDATE_DATE, NEW_STATUS)
    VALUES (p_update_id, p_baggage_tag_number, p_updated_by, SYSDATE, p_new_status);
    
    UPDATE BaggageTracking
    SET STATUS = p_new_status, LAST_UPDATED = SYSDATE
    WHERE BAGGAGE_TAG_NUMBER = p_baggage_tag_number;
END;
/
```

#### GenerateTrackingReport Procedure

```plsql
CREATE OR REPLACE PROCEDURE GenerateTrackingReport(
    p_report_id IN NUMBER
) AS
    v_total_baggage NUMBER;
    v_baggage_at_location CLOB;
    v_status_summary CLOB;
BEGIN
    -- Calculate total baggage
    SELECT COUNT(*) INTO v_total_baggage FROM BaggageTracking;
    
    -- Generate baggage at each location
    SELECT LISTAGG(CURRENT_LOCATION || ': ' || COUNT(*), ', ') WITHIN GROUP (ORDER BY CURRENT_LOCATION)
    INTO v_baggage_at_location
    FROM BaggageTracking
    GROUP BY CURRENT_LOCATION;
    
    -- Generate status summary
    SELECT LISTAGG(STATUS || ': ' || COUNT(*), ', ') WITHIN GROUP (ORDER BY STATUS)
    INTO v_status_summary
    FROM BaggageTracking
    GROUP BY STATUS;
    
    -- Insert report into TrackingReports table
    INSERT INTO TrackingReports (REPORT_ID, REPORT_DATE, TOTAL_BAGGAGE, BAGGAGE_AT_LOCATION, STATUS_SUMMARY)
    VALUES (p_report_id, SYSDATE, v_total_baggage, v_baggage_at_location, v_status_summary);
END;
/
```

## Usage Instructions

### Track Baggage
To track a new baggage, execute the `TrackBaggage` procedure with the required parameters:

```sql
EXEC TrackBaggage('TAG125', 'FL125', 'ORD', 'JFK', 'Checked In');
```

### Update Baggage Status
To update the status of a baggage, execute the `UpdateBaggageStatus` procedure with the required parameters:

```sql
EXEC UpdateBaggageStatus(3, 'TAG125', 'Agent3', 'Loaded');
```

### Generate Tracking Report
To generate a tracking report, execute the `GenerateTrackingReport` procedure with the required parameters:

```sql
EXEC GenerateTrackingReport(1);
```

## Testing

Test the procedures by:
- Tracking new baggage using the `TrackBaggage` procedure.
- Updating baggage statuses using the `UpdateBaggageStatus` procedure.
- Generating reports using the `GenerateTrackingReport` procedure.

Verify that the tables are updated correctly and that the generated reports provide the expected insights.
